
import java.io.IOException;
import java.io.PrintWriter;

import com.nhsapp.datamanager.DataManagerImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NHSAppServlet
 */
public class NHSAppServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NHSAppServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String postcode = request.getParameter("postcode");
		String postcodeFormat = postcode.toUpperCase();
		postcodeFormat = postcodeFormat.replaceAll(" ", "");

		String closestGP = null;
		String closestOptician = null;
		String closestDentist = null;
		
		response.setContentType("text/html");
		PrintWriter printWriter = response.getWriter();
		printWriter.print("<html>");
		printWriter.print("<head>");
		printWriter.print("<title>NHSAPP</title>");
		printWriter.print("<link rel=\"stylesheet\" href=\"NHSApp.css\">");
		printWriter.print("</head>");
		printWriter.print("<body>");
		printWriter.print("<h1>POSTCODE: " + postcodeFormat + "</h1>");
		
		try {
			boolean verify = new DataManagerImpl().verifyPostcode(postcodeFormat);
			if (verify == false) {
				printWriter.print("<p>The postcode you entered was invalid for this application<br>Only using bangor postcodes</p>");
			}
			else{
				try {
					closestGP = new DataManagerImpl().findClosestGP(postcodeFormat);
					printWriter.print("<p><b>NEAREST GP: </b><br> " + closestGP + "</p>");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					closestDentist = new DataManagerImpl().findClosestDentist(postcodeFormat);
					printWriter.print("<p><b>NEAREST DENTIST: </b><br> " + closestDentist + "</p>");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					closestOptician = new DataManagerImpl().findClosestOptician(postcodeFormat);
					printWriter.print("<p><b>NEAREST OPTICIAN: </b><br> " + closestOptician + "</p>");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		printWriter.print("</body>");
		printWriter.print("</html>");
		printWriter.close();
	}
}