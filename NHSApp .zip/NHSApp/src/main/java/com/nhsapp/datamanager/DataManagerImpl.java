package com.nhsapp.datamanager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.nhsapp.dto.LocationMethodsImpl;
import com.nhsapp.dto.ServiceMethodsImpl;
import com.nhsapp.dto.TypeMethodsImpl;

public class DataManagerImpl implements DataManager {
	private Connection conn;

	public DataManagerImpl() throws Exception {
		SimpleDataSource.init("database.properties");
		conn = SimpleDataSource.getConnection();
	}

	public double findLongitude(String postcode) {
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM location");
			Collection<LocationMethodsImpl> locationList = null;

			locationList = new LocationMethodsImpl().fromResultSet(rs);
			double longitude = 0;

			for (LocationMethodsImpl o : locationList) {
				if (postcode.equals(o.getPostCode().replaceAll(" ", ""))) {
					longitude = o.getLongitude();
				}
			}
			return longitude;
		} catch (SQLException e) {
			return 0;
		}
	}

	public double findLatitude(String postcode) {
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM location");
			Collection<LocationMethodsImpl> locationList = null;

			locationList = new LocationMethodsImpl().fromResultSet(rs);
			double latitude = 0;

			for (LocationMethodsImpl o : locationList) {
				if (postcode.equals(o.getPostCode().replaceAll(" ", ""))) {
					latitude = o.getLatitude();
				}
			}
			return latitude;
		} catch (SQLException e) {
			return 0;
		}
	}

	public double findDistance(double longitude1, double latitude1, double longitude2, double latitude2) {
		final double R = 3958.8; // Earth radius in Miles

		double lat1 = Math.toRadians(latitude1);
		double lon1 = Math.toRadians(longitude1);
		double lat2 = Math.toRadians(latitude1);
		double lon2 = Math.toRadians(longitude2);

		double dlon = lon2 - lon1;
		double dlat = lat2 - lat1;

		double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon / 2), 2);

		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

		return R * c; // Distance in Miles
	}

	@Override
	public String findClosestGP(String postcode) throws ClassNotFoundException, IOException, SQLException {

		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM service WHERE number=1");

		double userLong = findLongitude(postcode);
		double userLat = findLatitude(postcode);
		double smallestDistance = 1000000000000.00000;
		ServiceMethodsImpl closestGP = null;
		Collection<ServiceMethodsImpl> serviceList;

		serviceList = new ServiceMethodsImpl().fromResultSet(rs);

		for (ServiceMethodsImpl o : serviceList) {
			double serviceLong = findLongitude(o.getPostcode().replaceAll(" ", ""));
			double serviceLat = findLatitude(o.getPostcode().replaceAll(" ", ""));
			double distance = findDistance(userLong, userLat, serviceLong, serviceLat);
			o.setDistance(distance);
			;
		}

		for (ServiceMethodsImpl i : serviceList) {
			if (i.getDistance() < smallestDistance) {
				smallestDistance = i.getDistance();
				closestGP = i;
			}
		}

		return (closestGP.getName() + ", " + closestGP.getAddress() + ", " + closestGP.getPostcode() + ", "
				+ closestGP.getCity() + ", " + closestGP.getCounty());
	}

	@Override
	public String findClosestOptician(String postcode) throws ClassNotFoundException, IOException, SQLException {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM service WHERE number=3");

		double userLong = findLongitude(postcode);
		double userLat = findLatitude(postcode);
		double smallestDistance = 1000000000000.00000;
		ServiceMethodsImpl closestOptician = null;
		Collection<ServiceMethodsImpl> serviceList;

		serviceList = new ServiceMethodsImpl().fromResultSet(rs);

		for (ServiceMethodsImpl o : serviceList) {
			double serviceLong = findLongitude(o.getPostcode().replaceAll(" ", ""));
			double serviceLat = findLatitude(o.getPostcode().replaceAll(" ", ""));
			double distance = findDistance(userLong, userLat, serviceLong, serviceLat);
			o.setDistance(distance);
			;
		}

		for (ServiceMethodsImpl i : serviceList) {
			if (i.getDistance() < smallestDistance) {
				smallestDistance = i.getDistance();
				closestOptician = i;
			}
		}

		return (closestOptician.getName() + ", " + closestOptician.getAddress() + ", " + closestOptician.getPostcode()
				+ ", " + closestOptician.getCity() + ", " + closestOptician.getCounty());
	}

	@Override
	public String findClosestDentist(String postcode) throws ClassNotFoundException, IOException, SQLException {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM service WHERE number=2");

		double userLong = findLongitude(postcode);
		double userLat = findLatitude(postcode);
		double smallestDistance = 1000000000000.00000;
		ServiceMethodsImpl closestDentist = null;
		Collection<ServiceMethodsImpl> serviceList;

		serviceList = new ServiceMethodsImpl().fromResultSet(rs);

		for (ServiceMethodsImpl o : serviceList) {
			double serviceLong = findLongitude(o.getPostcode().replaceAll(" ", ""));
			double serviceLat = findLatitude(o.getPostcode().replaceAll(" ", ""));
			double distance = findDistance(userLong, userLat, serviceLong, serviceLat);
			o.setDistance(distance);
			;
		}

		for (ServiceMethodsImpl i : serviceList) {
			if (i.getDistance() < smallestDistance) {
				smallestDistance = i.getDistance();
				closestDentist = i;
			}
		}

		return (closestDentist.getName() + ", " + closestDentist.getAddress() + ", " + closestDentist.getPostcode()
				+ ", " + closestDentist.getCity() + ", " + closestDentist.getCounty());
	}

	public boolean verifyPostcode(String postcode) {
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM location");
			Collection<LocationMethodsImpl> locationList = null;

			locationList = new LocationMethodsImpl().fromResultSet(rs);
			boolean verify = false;
			for (LocationMethodsImpl o : locationList) {
				if (postcode.equals(o.getPostCode().replaceAll(" ", ""))) {
					verify = true;
				}
			}
			return verify;
		} catch (SQLException e) {
			return true;
		}
	}

}