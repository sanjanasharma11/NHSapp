package com.nhsapp.datamanager;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nhsapp.dto.LocationMethodsImpl;
import com.nhsapp.dto.ServiceMethodsImpl;
import com.nhsapp.dto.TypeMethodsImpl; 

public interface DataManager {
	
	public double findLongitude(String postcode);
	public double findLatitude(String postcode);
	
	
	/**
	 *Method to find which GP is located closest to the postcode provided.
	 *
	 *Will traverse through all the services, filtering which ones are GPs.
	 *Then it will compare the distances between each service using the findCoordinates() method and findDistance() method.
	 *From this it will decide which one is the shortest distance and then return this in a String format, ready to be presented on the main page.
	 *
	 *@param the postcode provided by the user.
	 *@return a string containing the name, address and general details of the closest GP.
	 */
	public String findClosestGP(String postcode) throws ClassNotFoundException, IOException, SQLException;
	
	
	/**
	 *Method to find which optician is located closest to the postcode provided.
	 *
	 *Will traverse through all the services, filtering which ones are opticians.
	 *Then it will compare the distances between each service using the findCoordinates() method and findDistance() method.
	 *From this it will decide which one is the shortest distance and then return this in a String format, ready to be presented on the main page.
	 *
	 *@param the postcode provided by the user
	 *@return a string containing the name, address and general details of the closest optician.
	 */
	public String findClosestOptician(String postcode) throws ClassNotFoundException, IOException, SQLException ;
	
	
	/**
	 *Method to find which dentist is located closest to the postcode provided.
	 *
	 *Will traverse through all the services, filtering which ones are dentists.
	 *Then it will compare the distances between each service using the findCoordinates() method and findDistance() method.
	 *From this it will decide which one is the shortest distance and then return this in a String format, ready to be presented on the main page.
	 *
	 *@param the postcode provided by the user
	 *@return a string containing the name, address and general details of the closest dentist.
	 */
	public String findClosestDentist(String postcode) throws ClassNotFoundException, IOException, SQLException ;
	
	/**
	 * Method Written by Qusai
	 * This will return the distance between 2 coordinates
	 * @param longitude1
	 * @param latitude1
	 * @param longitude2
	 * @param latitude2
	 * @return distance between 2 coordinates
	 */
	public double findDistance(double longitude1, double latitude1, double longitude2, double latitude2);
	}