package com.nhsapp.dto;

import java.util.Collection;
import java.util.LinkedList;
import java.sql.*;

public class ServiceMethodsImpl implements Methods<ServiceMethodsImpl> {
	private String name;
	private String city;
	private String county;
	private String address;
	private String postcode;
	private int number;
	private double distance;

	public ServiceMethodsImpl() {
	}

	public ServiceMethodsImpl(String name, String city, String county, String adress, String postcode, int number) {
		this.name = name;
		this.city = city;
		this.county = county;
		this.address = adress;
		this.postcode = postcode;
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public String getCity() {
		return city;
	}

	public String getCounty() {
		return county;
	}

	public String getAddress() {
		return address;
	}

	public String getPostcode() {
		return postcode;
	}

	public int getNumber() {
		return number;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public Collection<ServiceMethodsImpl> fromResultSet(ResultSet rs) {
		Collection<ServiceMethodsImpl> toReturn = new LinkedList<ServiceMethodsImpl>();
		try {
			while (rs.next()) {
				ServiceMethodsImpl m = new ServiceMethodsImpl(rs.getString("name"), rs.getString("city"),
						rs.getString("county"), rs.getString("address"), rs.getString("postcode"), rs.getInt("number"));
				toReturn.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return toReturn;
	}

}
