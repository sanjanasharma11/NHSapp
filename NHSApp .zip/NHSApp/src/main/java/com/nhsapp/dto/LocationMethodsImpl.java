package com.nhsapp.dto;

import java.util.Collection;
import java.util.LinkedList;
import java.sql.*;

public class LocationMethodsImpl implements Methods<LocationMethodsImpl> {

	private String postcode;
	private Double longitude;
	private Double latitude;
	
	public LocationMethodsImpl() {
	}

	public LocationMethodsImpl(String postcode, Double longitude, Double latitude) {
		this.postcode = postcode;
		this.longitude = longitude;
		this.latitude = latitude;
	}

	public String getPostCode() {
		return postcode;
	}

	public Double getLongitude() {
		return longitude;
	}

	public Double getLatitude() {
		return latitude;
	}
	
	public Collection<LocationMethodsImpl> fromResultSet(ResultSet rs) {
		Collection<LocationMethodsImpl> toReturn = new LinkedList<LocationMethodsImpl>();
		try {
			while (rs.next()) {
				LocationMethodsImpl l = new LocationMethodsImpl(rs.getString("postcode"), rs.getDouble("longitude"), rs.getDouble("latitude"));
				toReturn.add(l);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return toReturn;
	}
}