package com.nhsapp.dto;
import java.util.Collection;
import java.sql.ResultSet;

/**
 * Interface to define transformations between JDBS ResultSets/SQL and DTOs.
 * 
 * @param <T> The DTO Type.
 */
public interface Methods<T> {

	/**
	 * Create DTO instances for all results in the supplied ResultSet.
	 * 
	 * If there are no (compatible) results an empty collection should be returned.
	 * 
	 * @param rs The ResultSet to retrieve data from. It is assumed the Iterator is
	 *           prior to the first result.
	 * @return A collection of all valid returns
	 */
	Collection<T> fromResultSet(ResultSet rs);
}