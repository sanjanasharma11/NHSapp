package com.nhsapp.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

public class TypeMethodsImpl implements Methods<TypeMethodsImpl> {
	private int number;
	private String type;

	public TypeMethodsImpl(int number, String type) {
		this.number = number;
		this.type = type;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public Collection<TypeMethodsImpl> fromResultSet(ResultSet rs) {
		Collection<TypeMethodsImpl> toReturn = new LinkedList<TypeMethodsImpl>();
		try {
			while (rs.next()) {
				TypeMethodsImpl t = new TypeMethodsImpl(number, type);
				toReturn.add(t);
				System.out.println("Created new instance of Type");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return toReturn;
	}
}
